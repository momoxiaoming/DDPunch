require('share.adapter')  -- 任何业务模块中该文件必须导，且必须在依赖的模块后，比如  modUtil 模块
local modUtil = require('share.modUtil')      -- 函数内打日志必导项
local javaFun = require("share.javaFun")
local modUi = require("share.modUi")
local modUiBuz = require("share.modUiBuz")
local modAdrUi = require("share.modAdrUi")

-- 设备登录文件

-- 判断是否在登录页面
function toBeSingPage()



	-- body
	local  sucPgDef = 
        {
            maxMItemMSec = 10000,
            maxOItemMSec = 2000,
            must = {
                {uiResId = "com.alibaba.android.rimet:id/et_pwd_login"},
                {uiResId = "com.alibaba.android.rimet:id/et_phone_input"},
                {uiResId = "com.alibaba.android.rimet:id/login_has_problem"},
            },
            option = {
                {uiResId = "com.alibaba.android.rimet:id/btn_next"}
            } 

        }

    local rlt =  modUiBuz.isMyNeedPage(sucPgDef)
    
    return rlt


end

-- 执行登录
function doSignAction()
    -- 判断是否在登录页面
    local  sucPgDef = 
        {
            maxMItemMSec = 5000,
            maxOItemMSec = 2000,
            must = {
                {uiResId = "com.alibaba.android.rimet:id/et_pwd_login"},
                {uiResId = "com.alibaba.android.rimet:id/et_phone_input"},
                {uiResId = "com.alibaba.android.rimet:id/login_has_problem"},
            },
            option = {
                {uiResId = "com.alibaba.android.rimet:id/btn_next"}
            } 

        }

    local rlt =  modUiBuz.isMyNeedPage(sucPgDef)
    if(rlt) then
        -- 获取相关控件
        local acc=modUi.getUiObjWaitByResId('com.alibaba.android.rimet:id/et_phone_input',1000)
        local pwd=modUi.getUiObjWaitByResId('com.alibaba.android.rimet:id/et_pwd_login',1000)
        -- local login=modUi.getUiObjWaitByResId('com.alibaba.android.rimet:id/btn_next',5000)
        -- local logic=modUi.getUiObjWaitByResId('com.alibaba.android.rimet:id/btn_next',1000)


        -- modUtil.logE("两个输入框对象..."..acc)
        if(acc ==nil or pwd ==nil) then
            modUtil.logE("相关组件未找到")
        else
            inputAccAndPwd(acc,pwd)

            --点击登录按钮
            javaFun.pressBack()
            local x = modUi.findUiAndClickByResId('com.alibaba.android.rimet:id/btn_next',2000)
            if (x==true)then
              
                local  isPage = isMainPage()
                -- 登录结果传送到java 层
                javaFun.setTaskActionResult(isPage)
            else
                modUtil.logE("未找到登陆按钮")
                javaFun.setLoginResult(false)
            end

        end
    else
        javaFun.setLoginResult(false)
    end   

    
    

end


function isMainPage()
    -- body
    local  sucPgDef = 
        {
            maxMItemMSec = 10000,
            maxOItemMSec = 2000,
            must = {
                    {uiResId = "com.alibaba.android.rimet:id/home_bottom_tab_button_message"},
                    {uiResId = "com.alibaba.android.rimet:id/home_bottom_tab_button_mine"},
            },
            option = {
                    {uiResId = "com.alibaba.android.rimet:id/home_bottom_tab_button_contact"}, 
            }

        }
    local rlt =modUiBuz.isMyNeedPage(sucPgDef)
    return rlt
end

-- 输入账号密码
function inputAccAndPwd(accObj,pwdObj)
    -- body
    -- 点击账号输入框
    modAdrUi.clickUiObjNoWait(accObj)
    accObj:setText(acc_str)
    modUtil.sleep(1000)
    modAdrUi.clickUiObjNoWait(pwdObj)
    pwdObj:setText(pwd_str)

end


function doTask()
    -- 首先初始化程序到桌面
    javaFun.backToDeskTop()
    --启动钉钉
    javaFun.startApp('com.alibaba.android.rimet')

    --判断是否是主页
    local rlt =  isMainPage()
    if(rlt)then
        javaFun.setTaskActionResult(true)
    else
        --跳转打卡页
        if(toBeSingPage()) then
            doSignAction()

        end
    end

    javaFun.backToDeskTop()
    
    
    
 
end


-------------------------

acc_str=javaFun.getDingDingAccount()
pwd_str=javaFun.getDingDingPwd()

modUtil.logE("账号密码..."..acc_str..": "..pwd_str)

if(modUtil.isTextEmpty(acc_str) or modUtil.isTextEmpty(pwd_str)) then
    modUtil.logE("钉钉的账号密码为空...")
    return
end

if(javaFun.checkApkExist("com.alibaba.android.rimet")) then
    doTask()
else
    modUtil.logE("未发现钉钉应用...")
end