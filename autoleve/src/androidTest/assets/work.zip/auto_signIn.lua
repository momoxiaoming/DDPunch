require('share.adapter')  -- 任何业务模块中该文件必须导，且必须在依赖的模块后，比如  modUtil 模块
local modUtil = require('share.modUtil')      -- 函数内打日志必导项
local javaFun = require("share.javaFun")
local modUi = require("share.modUi")
local modUiBuz = require("share.modUiBuz")

-- 打卡文件

-- 传送到打卡页面
function toBeSingPage()
	-- body
	local needPgDef = 
	{
        {
            curPage = {
                maxMItemMSec = 7000,
                maxOItemMSec = 100,
                must = {
                    {uiResId = "com.alibaba.android.rimet:id/home_bottom_tab_button_message"},
                    {uiResId = "com.alibaba.android.rimet:id/home_bottom_tab_button_work"},
                    {uiResId = "com.alibaba.android.rimet:id/home_bottom_tab_button_mine"}
                },
                option = {
                    {uitxt = "通讯录"}, 
                    {uitxt = "DING"}
                }
            },
            maxWClickMSec = 300,
            click = {uiResId = "com.alibaba.android.rimet:id/home_bottom_tab_button_work"}
        },
        {
            curPage = {
                maxMItemMSec = 10000,
                maxOItemMSec = 100,
                must = {
                    {uitxt = "常用应用"},
                    {uitxt = "考勤打卡"},
                    {uitxt = "签到"}
                },
                option = {
                    {uitxt = "公告"}, 
                }
            },
            maxWClickMSec = 300,
            click = {uitxt = "考勤打卡"}
        }

    }
    modUiBuz.jumpToNeedPage(needPgDef)


    local  sucPgDef = 
        {
            maxMItemMSec = 10000,
            maxOItemMSec = 100,
            must = {
                    {uiResId = "com.alibaba.android.rimet:id/more_text"},
                },
                option = {
                    {uiDes = "打卡"},
                    {uiDes = "统计"},
                }
        }
    --判断是否在打卡页面
    local rlt =  modUiBuz.isMyNeedPage(sucPgDef)

    return rlt

end




-- 上班打卡
function up_sign()

    -- body
    local rlt =modUi.findUiAndClickByDes('上班打卡',5000)

    if(rlt)then
        local  sucPgDef = 
        {
            maxMItemMSec = 5000,
            maxOItemMSec = 1000,
            must = {
                {uiDes = "上班打卡成功"},
            },
            option = {
                {uiDes = "我知道了"}
            } 

        }
        local rlt =  modUiBuz.isMyNeedPage(sucPgDef)

        if (rlt) then
            javaFun.setTaskActionResultAndDesc(true,'无')

        else
            javaFun.setTaskActionResultAndDesc(false,'未发现打卡成功界面')

        end

    else  
        --找不到上班打卡按钮,有几个原因,1是迟到,2是已打卡了,3是没有节点,需要坐标打卡
        local  downRlt = findSignState(0)
        javaFun.setTaskActionResultAndDesc(downRlt,'未找到上班打卡按钮')
    end
end

-- 下班打卡
function down_sign()
    -- body

    local rlt =modUi.findUiAndClickByDes('下班打卡',5000)

    if(rlt)then
        local  sucPgDef = 
        {
            maxMItemMSec = 5000,
            maxOItemMSec = 100,
            must = {
                {uiDes = "下班班打卡成功"},
            },
            option = {
                {uiDes = "我知道了"}
            } 

        }
        local rlt =  modUiBuz.isMyNeedPage(sucPgDef)

        if (rlt) then
            javaFun.setTaskActionResultAndDesc(true,'无')

        else
            javaFun.setTaskActionResultAndDesc(false,'未发现打卡成功界面')

        end
    else
        modUtil.logE('未找到下班班打卡按钮')
        local  downRlt = findSignState(1)
        javaFun.setTaskActionResultAndDesc(downRlt,'未找到下班打卡按钮')
    end

end

-- 早退下班卡
function leave_down_sign()
    -- body
    local needPgDef = 
    {
        {
            curPage = {
                maxMItemMSec = 10000,
                maxOItemMSec = 100,
                must = {
                    {uiDes = "统计"},
                    {uiDes = "下班打卡"}
                },
                option = {
                    {uitxt = "帮助"}
                }
            },
            maxWClickMSec = 300,
            click = {uiDes = "下班打卡"}
        },
        {
            curPage = {
                maxMItemMSec = 10000,
                maxOItemMSec = 100,
                    must = {
                        {uiDes = "不打卡"},
                        {uiDes = "确定"}
                    },
                option = {
                    {uiDes = "确定要打早退卡吗?"}
                } 
            },
            maxWClickMSec = 5000,
            click = {uiDes = "确定"}
        }
    }

    local rlt = modUiBuz.jumpToNeedPage(needPgDef)

    if (rlt) then
        --
        local  sucPgDef = 
        {
            maxMItemMSec = 5000,
            maxOItemMSec = 100,
            must = {
                {uiDes = "下班打卡成功"},
            },
            option = {
                {uiDes = "我知道了"}
            } 

        }

        local rlt2 =  modUiBuz.isMyNeedPage(sucPgDef)

        if (rlt2) then
            javaFun.setTaskActionResultAndDesc(true,'无')
        else
            javaFun.setTaskActionResultAndDesc(false,'未发现打卡成功弹窗')
        end


    else
        javaFun.setTaskActionResultAndDesc(false,'未发现早退弹窗')

    end

end
-- 更新下班卡
function update_down_sign()
    -- body
    -- 进入了打卡页,点击更新打卡按钮
    local needPgDef = {
    {
            curPage = {
                maxMItemMSec = 7000,
                maxOItemMSec = 100,
                must = {
                    {uiDes = "更新打卡"}
                },
                option = {
                    {uitxt = "帮助"}
                }
            },
            maxWClickMSec = 3000,
            click = {uiDes = "更新打卡"}
        },
        {
            curPage = {
                maxMItemMSec = 5000,
                maxOItemMSec = 100,
                must = {
                    {uitxt = "确定要更新此次打卡记录吗?"},
                    {uitxt = "确定"}
                },
                option = {
                    {uitxt = "取消"}
                } 
            },
            maxWClickMSec = 300,
            click = {uitxt = "确定"}
        }
    }


    if (modUiBuz.jumpToNeedPage(needPgDef)) then
        -- 点击更新按钮成功后,判断是否出现了弹窗
        local update = {
            maxMItemMSec = 10000,
            maxOItemMSec = 100,
            must = {
                {uiDes = "不打卡"},
                {uiDes = "确定"}
            },
            option = {
                {uiDes = "确定要打早退卡吗?"}
            } 
        }

        local rlt =  modUiBuz.isMyNeedPage(update)
         -- 点击确定之后分两种情况,
        -- 未到下班时间打更新卡,会提示早退弹窗,需要点掉早退弹窗
        if(rlt) then
            modUtil.logE('发现早退弹窗....')
            -- 处理弹窗
            local toPgDef = 
            {    
                {
                    curPage = {
                        maxMItemMSec = 10000,
                        maxOItemMSec = 100,
                        must = {
                            {uiDes = "不打卡"},
                            {uiDes = "确定"}
                        },
                        option = {
                            {uiDes = "确定要打早退卡吗?"}
                        } 
                    },
                    maxWClickMSec = 300,
                    click = {uiDes = "确定"}
                }
            
            }

            modUiBuz.jumpToNeedPage(toPgDef)
        end


        -- 判断是否更新打卡成功

        local  sucPgDef = 
        {
            maxMItemMSec = 5000,
            maxOItemMSec = 100,
            must = {
                {uiDes = "下班打卡成功"},
            },
            option = {
                {uiDes = "我知道了"}
            } 

        }

        local rlt2 =  modUiBuz.isMyNeedPage(sucPgDef)

        if (rlt2) then
            javaFun.setTaskActionResultAndDesc(true,'无')

        else
            javaFun.setTaskActionResultAndDesc(false,'未找到打卡成功页面')

        end

        
    else
        -- 
        javaFun.setTaskActionResultAndDesc(false,'进入更新打卡页面失败')

    end
end

-- signType 0是上班,1是下班
function findSignState(signType)
    -- 判断是否已打卡
    local rltNum = modUi.getUiCollChildCountByDescNm('android.widget.ListView','打卡时间',10000)
    modUtil.logE(rltNum)

    if (rltNum==0)then
        -- 没有找到时间按钮,可能是web导致节点未找到,需要进行坐标打卡
        javaFun.doSignClick(signType+1)
        return false;  --默认是返回false,需要jav层通知去修改
    elseif (rltNum>signType)then
        return true
    else
        return false
    end

end

-- 执行相关的打卡任务
function exeSignTask()
    -- body
    if(toBeSingPage())then
        --1002 上班卡,1003 下班卡,1004早退下班,1005更新下班
        local signType = javaFun.getPushType()

        if (signType==1002) then
            up_sign()
        elseif (signType==1003) then
            down_sign()
        elseif (signType==1004) then
            leave_down_sign()
        elseif (signType==1005) then
            update_down_sign()
        end

    else
        javaFun.setTaskActionResultAndDesc(false,'进入打卡页面失败')

    end

end





function doTask()
	-- body
    -- 首先初始化程序到桌面
    javaFun.backToDeskTop()
    --启动钉钉
	javaFun.startApp('com.alibaba.android.rimet')
    --跳转打卡页
	exeSignTask()
     -- 回退到桌面
    javaFun.backToDeskTop()
end




if(javaFun.checkApkExist("com.alibaba.android.rimet")) then
    doTask()
else
    modUtil.logE("no dingding...")
end