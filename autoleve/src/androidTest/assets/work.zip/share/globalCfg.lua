-------------------------------------------------- 全局层面配置文件 -------------------------------------------------------
globalCfg = {
    workEnv = "adr",  -- 工作环境：windowsPC: "win32";  安卓："adr"; 苹果手机:"ios"; 苹果电脑:"mac"

    SRCH_UI_MTH = {  -- 查找UI方式
        RESID = "uiResId", -- 根据资源 ID 值
        TXT = "uitxt",     -- 根据全文本信息
        TXTSTART = "uitxtStart", -- 根据文本开始信息
        DES  = "uiDes", -- 根据描述信息
        CLSNM = "uiClsNm", -- 根据文本类名信息
    },

    CONFIG_FILE_NAME = "lua_config.txt"
}


return globalCfg