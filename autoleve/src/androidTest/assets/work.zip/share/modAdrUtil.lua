--------------------------------------------------模块：Android 基本工具模块封装  -------------------------------------------------------
-- 说明：为所有其他模块提供 Android 手机基本开发API工具套件

require 'import'
import 'com.al.autoleve.core.automator.util.LogUtil'
import 'com.al.autoleve.core.automator.util.TimeUtil'
import 'com.al.autoleve.core.automator.api.AutomatorApi'


local modAdrUtil = {
}

-- ========================= 日志与时间 ==============================
-- 普通信息日志打印
function modAdrUtil.logI(logStr)
    LogUtil:logic_i(logStr)
end

-- 错误信息日志打印
 function modAdrUtil.logE(logStr)
    LogUtil:logic_e(logStr)
end

-- 休眠毫秒时间
 function modAdrUtil.sleep(mSec)
    AutomatorApi:mSleep(mSec)
end

-- 获取当前毫秒值utc时间戳
 function modAdrUtil.getCurrentUtcMsc()
    return TimeUtil:getCurrentTimeInLong()
end

-- ========================= 模块返回，必须有 ==============================
return modAdrUtil