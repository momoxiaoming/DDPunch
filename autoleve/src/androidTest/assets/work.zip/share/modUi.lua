-------------------------------------------------- 模块：高级UI操作模块 -------------------------------------------------------
-- 说明：为UI界面功能开发提供安全的API工具套件, 模块命名规则：mod + 具体模块名
local GCfg = require("share.globalCfg")
local modUtil = require("share.modUtil")
local modAdrUtil = require("share.modAdrUtil")
local modAdrUi = require("share.modAdrUi")
gModAdrUi = modAdrUi


local modUi = {
    WAIT_UI_APPEAR_MSEC = 2 * 1000, -- 默认等待 UI 控件出现毫秒时间
    CHECK_UI_SLEEP_GAP_MSEC = 100   -- 默认轮询检测 UI 出现的间隔毫秒时间 
}


-- ========================= 内部通用函数 ==============================
-- 获取 UI 控件对象直到超时
function __getUiObjUntilTimeout(maxMSec, cbUiObjGetFuncStr, ...)
    local ld = loadstring or load
    local uiObj = nil
    local beginUtcMsc = modAdrUtil.getCurrentUtcMsc() 
    local curUtcMsc = beginUtcMsc;

    if (maxMSec == nil or maxMSec < 0) then
        maxMSec = modUi.WAIT_UI_APPEAR_MSEC
    end

    while (true) do
        uiObj = ld('return ' .. cbUiObjGetFuncStr .. '(...)')(...)   -- or load
        
        if (modAdrUi.isUiObjExists(uiObj)) then
            break
        else
            uiObj = nil
            curUtcMsc = modAdrUtil.getCurrentUtcMsc() 

            if(modUtil.utcTimeDiff(curUtcMsc, beginUtcMsc) < maxMSec) then
                modAdrUtil.sleep(modUi.CHECK_UI_SLEEP_GAP_MSEC)
            else
                break
            end   
        end
    end

    return uiObj    
end


-- ========================= 快速获取基本 UI 对象 ==============================
--判断指定的 View 对象是否存在
--[[function modUi.isUiObjExists(vwObj)
    return (vwObj ~= nil)
end]]


-- 根据选择器对象，在指定时间段内查找 UI View 对象, maxMSec 为零时表示马上获取结果
function modUi.getUiObjWaitBySel (selObj, maxMSec)
    return __getUiObjUntilTimeout(maxMSec, "gModAdrUi.getUiObjNoWaitBySel", selObj)
end

-- 根据 UI 控件 ID 字串，在指定时间段内查找 UI View 对象
function modUi.getUiObjWaitByResId(resIdStr, maxMSec)
    return modUi.getUiObjWaitBySel(modAdrUi.createUiSelByResId(resIdStr), maxMSec)
end

-- 根据 UI 控件类名，在指定时间段内查找 UI View 对象
function modUi.getUiObjWaitByClsNm(clsNm, maxMSec)
    return modUi.getUiObjWaitBySel(modAdrUi.createUiSelByClsNm(clsNm), maxMSec)
end

-- 根据 UI 控件文本全内容，在指定时间段内查找 UI View 对象
function modUi.getUiObjWaitByText (txtStr, maxMSec)
    return modUi.getUiObjWaitBySel(modAdrUi.createUiSelByText(txtStr), maxMSec)
end

-- 根据 UI 控件文本全内容，在指定时间段内查找 UI View 对象
function modUi.getUiObjWaitByTextStartWith (txtStartWithStr, maxMSec)
    return modUi.getUiObjWaitBySel(modAdrUi.createUiSelByTextStartWith(txtStartWithStr), maxMSec)
end

-- 根据 UI 控件描述内容，在指定时间段内查找 UI View 对象
function modUi.getUiObjWaitByDes (desStr, maxMSec)
    return modUi.getUiObjWaitBySel(modAdrUi.createUiSelByDes(desStr), maxMSec)
end

-- 为上层提供基于字串指定模式来获取 UI View 对象
function modUi.getUiObjWait(uiSrchMth, uiSrchStr, maxMSec)
    local uiObj = nil

    if((not modUtil.isTextEmpty(uiSrchMth)) and (not modUtil.isTextEmpty(uiSrchStr))) then
        if(uiSrchMth == GCfg.SRCH_UI_MTH.RESID) then
            uiObj = modUi.getUiObjWaitByResId(uiSrchStr, maxMSec)
        elseif(uiSrchMth == GCfg.SRCH_UI_MTH.TXT) then
            uiObj =  modUi.getUiObjWaitByText(uiSrchStr, maxMSec)
        elseif(uiSrchMth == GCfg.SRCH_UI_MTH.TXTSTART) then
            uiObj = modUi.getUiObjWaitByTextStartWith(uiSrchStr, maxMSec)
        elseif(uiSrchMth == GCfg.SRCH_UI_MTH.DES) then
            uiObj = modUi.getUiObjWaitByDes(uiSrchStr, maxMSec)
        elseif(uiSrchMth == GCfg.SRCH_UI_MTH.CLSNM) then
            uiObj = modUi.getUiObjWaitByClsNm(uiSrchStr, maxMSec)
        end
     end

     return uiObj
end

-- ========================= 点击 UI 控制对象 ==============================
-- 基于选择器对象，在指定毫秒长时间内找到 UI 控件并点击，执行点击后返回真，未找到返回假
function modUi.findUiAndClickBySel(selObj, maxMSec)
    return modAdrUi.clickUiObjNoWait(modUi.getUiObjWaitBySel(selObj, maxMSec))
end

-- 基于UI控件的ID字串，在指定毫秒长时间内找到 UI 控件并点击，执行点击后返回真，未找到返回假
function modUi.findUiAndClickByResId(resIdStr, maxMSec)
    return modAdrUi.clickUiObjNoWait(modUi.getUiObjWaitByResId(resIdStr, maxMSec))
end

-- 基于UI控件的全字串内容，在指定毫秒长时间内找到 UI 控件并点击，执行点击后返回真，未找到返回假
function modUi.findUiAndClickByText(txtStr, maxMSec)
    return modAdrUi.clickUiObjNoWait(modUi.getUiObjWaitByText(txtStr, maxMSec))
end

function modUi.findUiAndClickByDes(destStr, maxMSec)
    return modAdrUi.clickUiObjNoWait(modUi.getUiObjWaitByDes(destStr, maxMSec))
end

-- 基于UI控件的全字串内容，在指定毫秒长时间内找到 UI 控件并点击，执行点击后返回真，未找到返回假
function modUi.findUiAndClickByTextStartWith(txtStartWithStr, maxMSec)
    return modAdrUi.clickUiObjNoWait(modUi.getUiObjWaitByTextStartWith(txtStartWithStr, maxMSec))
end


-- ========================= 获取 UI 对象的Text、Des =========================

-- 根据 UI 控件选择器，获取对象的text
function modUi.getTextBySel(selector, defaultText, maxMSec)
    local vwObj = modUi.getUiObjWaitBySel(selector,maxMSec)
    return modAdrUi.getTextByUiObj(vwObj, defaultText)
end

-- 根据 UI 控件ID，获取对象的text
function modUi.getTextByResId(resStr, defaultText, maxMSec)
    local vwObj = modUi.getUiObjWaitByResId(resStr,maxMSec)
    return modAdrUi.getTextByUiObj(vwObj, defaultText)
end

-- 根据 UI 控件ID，获取对象的text
function modUi.getTextByClsNm(clsNm, defaultText, maxMSec)
    local vwObj = modUi.getUiObjWaitByClsNm(clsNm,maxMSec)
    return modAdrUi.getTextByUiObj(vwObj, defaultText)
end

-- 根据 UI 控件选择器，获取对象的描述信息Des
function modUi.getDesBySel(selector, defaultDes, maxMSec)
    local vwObj = modUi.getUiObjWaitBySel(selector,maxMSec)
    return modAdrUi.getDesByUiObj(vwObj, defaultDes)
end

-- 根据 UI 控件选择器，获取对象的描述信息Des
function modUi.getDesByResId(resStr, defaultDes, maxMSec)
    local vwObj = modUi.getUiObjWaitByResId(resStr,maxMSec)
    return modAdrUi.getDesByUiObj(vwObj, defaultDes)
end

-- ========================= 快速获取 UI 控件集合 =========================
-- 根据子资源 ID 条件值获取 Ui 集合中子 Ui 个数
function modUi.getUiCollChildCountBySel (collObj, childSel, maxMSec)
    local vwCount = 0
    local beginUtcMsc = modAdrUtil.getCurrentUtcMsc() 
    local curUtcMsc = beginUtcMsc;

    if (maxMSec == nil or maxMSec < 0) then
        maxMSec = modUi.WAIT_UI_APPEAR_MSEC
    end

    if(collObj == nil or childSel == nil) then
        return vwCount
    end

    while (true) do
        vwCount = modAdrUi.getUiCollChildCountBySel(collObj, childSel)
        
        if (vwCount ~= 0) then
            break
        else
            vwCount = 0
            curUtcMsc = modAdrUtil.getCurrentUtcMsc() 

            if(modUtil.utcTimeDiff(curUtcMsc, beginUtcMsc) < maxMSec) then
                modAdrUtil.sleep(modUi.CHECK_UI_SLEEP_GAP_MSEC)
            else
                break
            end   
        end
    end

    return vwCount
end

-- 根据子资源 ID 条件值获取 Ui 集合中子 Ui 个数
function modUi.getUiCollChildCountByResId(collObj, childResIdStr, maxMSec)
    return modUi.getUiCollChildCountBySel(collObj, modAdrUi.createUiSelByResId(childResIdStr), maxMSec)
end

-- 根据子类名 条件值获取 Ui 集合中子 Ui 个数
function modUi.getUiCollChildCountByClsNm(collObj, childClsNmStr, maxMSec)
    return modUi.getUiCollChildCountBySel(collObj, modAdrUi.createUiSelByClsNm(childClsNmStr), maxMSec)
end

-- 根据集合类名 和 子资源 ID 条件值获取 Ui 集合中子 Ui 个数
function modUi.getUiCollChildCountByClsNmAResId(collclsNmStr, childResIdStr, maxMSec)
    local collObj = modAdrUi.getUiCollByClsNm(collclsNmStr)
    return modUi.getUiCollChildCountByResId(collObj, childResIdStr, maxMSec)
end

-- 根据集合资源 ID 和 子资源 ID 条件值获取 Ui 集合中子 Ui 个数
function modUi.getUiCollChildCountByResIdAClsNm(collResIdStr, childClsNmStr, maxMSec)
    local collObj = modAdrUi.getUiCollByResId(collResIdStr)
    return modUi.getUiCollChildCountByClsNm(collObj, childClsNmStr, maxMSec)
end

-- 获取 Ui 集合中指定的索引位置的子对象
function modUi.getUiCollChildByInstance(collObj, childSel, idx, maxMSec)
    local vwObj = nil

    if(collObj ~= nil and childSel ~= nil) then
        vwObj = __getUiObjUntilTimeout(maxMSec, "gModAdrUi.getUiCollChildByInstance", collObj, childSel, idx)
    end
    return vwObj
end

-- 集合类名 和 子资源 ID ,获取 Ui 集合中指定的索引位置的子对象
function modUi.getUiCollChildByClsNmAResIdAInstance(collclsNmStr, childResIdStr, idx, maxMSec)
    local collObj = modAdrUi.getUiCollByClsNm(collclsNmStr)
    local childSel = modAdrUi.createUiSelByResId(childResIdStr)
    return modUi.getUiCollChildByInstance(collObj, childSel, idx, maxMSec)
end

-- 集合类名 和 子资源 ID ,获取 Ui 集合中指定的索引位置的子对象
function modUi.getUiCollChildBy2ResIdAInstance(collResIdStr, childResIdStr, idx, maxMSec)
    local collObj = modAdrUi.getUiCollByResId(collResIdStr)
    local childSel = modAdrUi.createUiSelByResId(childResIdStr)
    return modUi.getUiCollChildByInstance(collObj, childSel, idx, maxMSec)
end

-- 集合资源 ID 和 子资源 ID ,获取 Ui 集合中指定的索引位置的子对象
function modUi.getUiCollChildByResIdAClsNmAInstance(collResIdStr, childclsNmStr, idx, maxMSec)
    local collObj = modAdrUi.getUiCollByResId(collResIdStr)
    local childSel = modAdrUi.createUiSelByClsNm(childclsNmStr)
    return modUi.getUiCollChildByInstance(collObj, childSel, idx, maxMSec)
end

-- 获取 Ui 集合中指定资源 ID 及 序数的文本内容
function modUi.getUiCollChildTextByInstance(collObj, childSel, idx, defaultTxt, maxMSec)
    local childObj = modUi.getUiCollChildByInstance(collObj, childSel, idx, maxMSec)
    return modAdrUi.getTextByUiObj(childObj, defaultTxt)
end

-- 集合类名 和 子资源 ID ,获取 Ui 集合中指定资源 ID 及 序数的文本内容
function modUi.getUiCollChildTextByClsNmAResIdAInstance(collclsNmStr, childResIdStr, idx, defaultTxt, maxMSec)
    local childObj = modUi.getUiCollChildByClsNmAResIdAInstance(collclsNmStr, childResIdStr, idx, maxMSec)
    return modAdrUi.getTextByUiObj(childObj, defaultTxt)
end

-- 集合类名 和 子资源 ID ,获取 Ui 集合中指定资源 ID 及 序数的文本内容
function modUi.getUiCollAllChildTextByResIdAClsNm(collResIdStr, childClsNmStr, defChildTxt, maxMSec)
    local collObj = modAdrUi.getUiCollByResId(collResIdStr)
    local childSel = modAdrUi.createUiSelByClsNm(childClsNmStr)
    return modUi.getUiCollAllChildTextByCollObjAClsNm(collObj, childSel, defChildTxt, maxMSec)
end

--获取子类名相同的所有子项的text
function modUi.getUiCollAllChildTextByCollSelAClsNm(collSel, childClsNmStr, defChildTxt, maxMSec)
    local collObj = modAdrUi.getUiCollBySel(collSel)
    local childSel = modAdrUi.createUiSelByClsNm(childClsNmStr)
    return modUi.getUiCollAllChildTextByCollObjAClsNm(collObj, childSel, defChildTxt, maxMSec)
end

-- 集合类名 和 子资源 ID ,获取 Ui 集合中指定资源 ID 及 序数的文本内容
function modUi.getUiCollAllChildTextByCollObjAClsNm(collObj, childSel, defChildTxt, maxMSec)
    local rltTb = {}
    local childCount = modUi.getUiCollChildCountBySel(collObj, childSel, maxMSec)
    for i=0,childCount-1 do
        local childObj = modUi.getUiCollChildByInstance(collObj, childSel, i, maxMSec)
        local childTxt = modAdrUi.getTextByUiObj(childObj, defChildTxt)
        table.insert( rltTb, childTxt)
    end
    return rltTb
end

-- 获取 Ui 集合中指定资源 ID 及 序数的描述内容
function modUi.getUiCollChildDesByInstance(collObj, childSel, idx, defaultDes, maxMSec)
    local childObj = modUi.getUiCollChildByInstance(collObj, childSel, idx, maxMSec)
    return modAdrUi.getDesByUiObj(childObj, defaultDes)
end

-- ========================= UI 控件操作 ==================================
function modUi.getListViewItemSubsetTextsByItemSel(collObj, itemSel, subsetDefTb, maxMSec)
    local rltVwTexts = {}
    local count = modUi.getUiCollChildCountBySel(collObj, itemSel, maxMSec)

    if (count <= 0) then
        return rltVwTexts
    end

    for idx = 0, count - 1 do
        local itemSubset = {}
        local isDataValid = true
   
        local itemObj = modUi.getUiCollChildByInstance(collObj, itemSel, idx, maxMSec)
        for j = 1, #subsetDefTb do
            local mthod = subsetDefTb[j]["mthod"]
            local name = subsetDefTb[j]["name"]
            local value = subsetDefTb[j]["value"]

            itemSubset[name] = modAdrUi.getTextByUiObj(modAdrUi.getChildUiObjNoWaitBySel(itemObj, modAdrUi.createUiSel(mthod, value)), "")

            if (itemSubset[name] == "") then
                isDataValid = false
                break
            end
        end 

        if (isDataValid) then
            table.insert(rltVwTexts, itemSubset)
        end
    end

    return rltVwTexts
end

-- ========================= UI 控件属性 ==================================
-- 获取 UI 对象的高度, 无法获取或本身高度为零时返回 0
function modUi.getUiObjHeightByByResId(resIdStr)
    local vwObj = modUi.getUiObjWaitByResId(resIdStr)
    return modAdrUi.getUiObjHeight(vwObj)
end

function modUi.checkUiObjExistsWait(vmObj,maxMSec)
    local beginUtcMsc = modUtil.getCurMSec()
    local curUtcMsc = beginUtcMsc
    while(true) do
        if (modAdrUi.isUiObjExists(vmObj)) then
            return true
        else
            curUtcMsc = modUtil.getCurMSec()
            if(modUtil.utcTimeDiff(curUtcMsc, beginUtcMsc) > maxMSec) then
                break
            end   
            modUtil.sleep(modUi.CHECK_UI_SLEEP_GAP_MSEC)
        end
    end
    return false
end

--在maxMSec时间间隔内检查vmObj是否是不存在，True表示不存在，false表示存在
function modUi.checkUiObjNotExistsWait(vmObj,maxMSec)
    local beginUtcMsc = modUtil.getCurMSec()
    local curUtcMsc = beginUtcMsc
    while(true) do
        if (not modAdrUi.isUiObjExists(vmObj)) then
            return true
        else
            curUtcMsc = modUtil.getCurMSec()
            if(modUtil.utcTimeDiff(curUtcMsc, beginUtcMsc) > maxMSec) then
                break
            end   
            modUtil.sleep(modUi.CHECK_UI_SLEEP_GAP_MSEC)
        end
    end
    return false
end
-- ========================= 模块返回，必须有 ==============================
return modUi