------------------------------------------ 适配 安卓 平台 -----------------------------------
local mdUtil = require('share.modUtil')
local mdAdrUi = require("share.modAdrUtil")

local adapterAdr = {}

function adapterAdr.initAdapter()
    mdUtil.init(mdAdrUi.sleep, mdAdrUi.getCurrentUtcMsc, mdAdrUi.logI, mdAdrUi.logE)
end

return adapterAdr