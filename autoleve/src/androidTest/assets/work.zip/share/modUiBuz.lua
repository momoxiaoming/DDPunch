-------------------------------------------------- 模块：业务UI操作模块 -------------------------------------------------------
-- 说明：为UI界面功能开发提供安全的API工具套件, 模块命名规则：mod + 具体模块名
local modUtil = require("share.modUtil")
local modUi =  require("share.modUi")
local modAdrUi =  require("share.modAdrUi")

local modUiBuz = {}

local PageDefKey = {
    PAGE_UI_MAXMITEMMSEC = "maxMItemMSec",
    PAGE_UI_MAXOITEMMSEC = "maxOItemMSec",
    PAGE_MUST_KEY = "must",
    PAGE_OPT_KEY = "option",
}

local ClickDefKey = {
    PAGE_UI_CURPAGE             = "curPage",
    PAGE_UI_MAXWCLICKMSEC       = "maxWClickMSec",
    PAGE_UI_CLICK               = "click"
}

-- ========================= 业务常用函数 ==============================
-- 判断指定控件是否消失，业务逻辑可以根据改返回值做后续操作
-- startIdleMSec： 最开始等待时间(单位：毫秒)：
-- uiMatchType： 指定定位 UI 用的 uiMatchStr 字串类型；目前支持如下几种方式：uiResId, uitxt, uitxtStart, uiClsNm
-- uiMatchStr ： 定位 UI 的字串
-- maxMSec    ： 最大等待时间，包含了startIdleMSec的等待时间(单位：毫秒)
function waitUiObjPassOff(startIdleMSec, uiMatchType, uiMatchStr, maxMSec)
    local isPassOff = false
    local checkGapMSec = 50
    local beginUtcMsc = modUtil.getCurrentUtcMsc() 
    local curUtcMsc = beginUtcMsc
    local uiObj = nil

    if (not modUtil.isTextEmpty(uiMatchStr)) then
        if (0 < startIdleMSec) then
            modUtil.sleep(startIdleMSec)
        end

        repeat      
            uiObj = modUi.getUiObjWait(uiMatchType, uiMatchStr, 0)
            if (modUi.isUiObjExists(uiObj)) then
                modUtil.sleep(checkGapMSec)
            else
                isPassOff = true
                break
            end
            
            curUtcMsc = modUtil.getCurrentUtcMsc() 
    
        until (modUtil.abs(curUtcMsc - beginUtcMsc) > maxMSec)
    end

    return isPassOff
end

local function __clickUiObj(uiMatchType, uiMatchStr, maxMSec)
    local vmObj = modUi.getUiObjWait(uiMatchType, uiMatchStr, maxMSec)
    return modAdrUi.clickUiObjNoWait(vmObj)
end 

function modUiBuz.isMyNeedPage(pageDefTb)
    local isMyPage = false

    if(pageDefTb ~= nil and type(pageDefTb) == "table" and pageDefTb[PageDefKey.PAGE_UI_MAXMITEMMSEC] ~= nil and pageDefTb[PageDefKey.PAGE_UI_MAXOITEMMSEC] ~= nil) then
        local maxMMSec = pageDefTb[PageDefKey.PAGE_UI_MAXMITEMMSEC]
        local maxOMSec = pageDefTb[PageDefKey.PAGE_UI_MAXOITEMMSEC]

        local isMustMatch = true
        local pgMust = pageDefTb[PageDefKey.PAGE_MUST_KEY]
        if(pgMust ~= nil and type(pgMust) == "table" and 0 < #pgMust) then
            for i = 1, #pgMust do
                for key, value in pairs(pgMust[i]) do
                    if(modUi.getUiObjWait(key, value, maxMMSec) == nil) then
                        isMustMatch = false
                        break
                    end
                end
                if(not isMustMatch) then
                    break
                end
            end
        end

        local isOptionMatch = false
        if(isMustMatch) then 
            local pgOpt = pageDefTb[PageDefKey.PAGE_OPT_KEY]
            if(pgOpt ~= nil and type(pgOpt) == "table" and 0 < #pgOpt) then
                for i = 1, #pgOpt do
                    isOptionMatch = true
                    for j = 1, #pgOpt[i] do
                        for key, value in pairs(pgOpt[i][j]) do
                            if(modUi.getUiObjWait(key, value, maxOMSec) == nil) then
                                isOptionMatch = false
                                break
                            end
                        end
                        if(not isOptionMatch) then
                            break
                        end
                    end

                    if(isOptionMatch) then
                        break
                    end
                end
            else
                isOptionMatch = true
            end
        end

        isMyPage = isMustMatch and isOptionMatch
    end

    return isMyPage
end

local jumpToNeedPage = false
function modUiBuz.jumpToNeedPage(needPgDefTb)

    if(needPgDefTb ~= nil and type(needPgDefTb) == "table") then
        for i,itemV in ipairs(needPgDefTb) do
            local curPage = itemV[ClickDefKey.PAGE_UI_CURPAGE]
            local click = itemV[ClickDefKey.PAGE_UI_CLICK]
            local maxWClickMSec = itemV[ClickDefKey.PAGE_UI_MAXWCLICKMSEC]

            if( curPage ~= nil  and type(curPage) == "table" and click ~= nil  and type(click) == "table"  and maxWClickMSec ~= nil) then
                if (modUiBuz.isMyNeedPage(curPage)) then
                    
                    for key,value in pairs(click) do
                        jumpToNeedPage = __clickUiObj(key, value, maxWClickMSec)
                        if (jumpToNeedPage) then
                            break
                        end
                    end

                else
                    jumpToNeedPage = false
                    modUtil.logE("不在预期的界面，无法跳转...")
                end
            end

            if (not jumpToNeedPage) then
                break
            end
        end
    end

    return jumpToNeedPage
end

return modUiBuz