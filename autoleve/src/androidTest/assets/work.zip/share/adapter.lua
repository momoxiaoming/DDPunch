------------------------------------------ 自适配平台 -----------------------------------
local gCfg = require('share.globalCfg')

local adapter = {}

-- 空函数
local function doNone()
    return true
end

-- 自动适配平台
function adapter.initAdaptert()
    if(gCfg.workEnv == "win32") then
        doNone()
    elseif(gCfg.workEnv == "adr") then
        local adapterAdr = require('share.adapterAdr')
        adapterAdr.initAdapter()
    elseif(gCfg.workEnv == "ios") then
        doNone()
    elseif(gCfg.workEnv == "mac") then
        doNone()
    end
end

adapter.initAdaptert()

return adapter
