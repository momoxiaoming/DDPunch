--------------------------------------------------模块：Android 设备界面操作模块封装  -------------------------------------------------------
-- 说明：为所有其他模块提供 Android 设备界面操作基本开发API工具套件

require 'import'
import 'com.al.autoleve.core.automator.api.UiCollectionApi'
import 'com.al.autoleve.core.automator.api.UiScrollableApi'
import 'com.al.autoleve.core.automator.api.UiSelectorApi'
import 'com.al.autoleve.core.automator.api.UiObjectApi'
import 'com.al.autoleve.core.automator.api.AutomatorApi'
import 'com.al.autoleve.core.automator.util.LogUtil'

local GCfg = require("share.globalCfg")
local modUtil = require("share.modUtil")

local RECT = {left = "left", right = "right", top = "top", bottom="bottom", centerX="centerX", centerY="centerY"}

local modAdrUi = {
    __DEF_LONG_PRESS_STEPS = 50, -- 默认长按步长值
}

-- ========================= 按键与滑动操作 ==============================
-- 指定各坐标值的滑动操作, 以及滑动方式
local function __swipe(xStart, yStart, xEnd, yEnd, step, swpType)
    if(swpType ~= nil) then
        if(swpType == "y") then
            xEnd = xStart
        elseif(swpType == "x") then
            yEnd = yStart
        end
    end

    AutomatorApi:swipe(xStart, yStart, xEnd, yEnd, step)
end

-- 指定坐标点的滑动操作, 以及滑动方式 point 传入样列: startPoint: {x=100, y=120} 
local function __swipeByPoint(startPoint, endPoint, step, swpType)
    local isSwiped = false

    if(startPoint ~= nil and endPoint ~= nil and type(startPoint) == "table" and type(endPoint) == "table") then
        isSwiped = true
        __swipe(startPoint.x, startPoint.y, endPoint.x, endPoint.y, step, swpType)
    end

    return  isSwiped
end

-- 指定各坐标值的滑动操作
function modAdrUi.swipe(xStart, yStart, xEnd, yEnd, step)
    __swipe(xStart, yStart, xEnd, yEnd, step, "xy")
end

-- 指定坐标点的滑动操作, point 传入样列: startPoint: {x=100, y=120}
function modAdrUi.swipeByPoint(startPoint, endPoint, step)
    return __swipeByPoint(startPoint, endPoint, step, "xy")
end

-- 指定坐标点按X轴滑动， y方向上不动
function modAdrUi.swipeByPointX(startPoint, endPoint, step)
    return __swipeByPoint(startPoint, endPoint, step, "x")
end

-- 指定坐标点按y轴滑动， x方向上不动
function modAdrUi.swipeByPointX(startPoint, endPoint, step)
    return __swipeByPoint(startPoint, endPoint, step, "y")
end

-- 手机按返回键
function modAdrUi.pressBack()
    AutomatorApi:pressBack()
end

-- 手机按 Home 键
function modAdrUi.pressHome()
    AutomatorApi:pressHome()
end

function modAdrUi.longPress(uiObj)
    local isLongPressed = false
    local rect = modAdrUi.getUiObjRect(uiObj)
    
    if(rect ~= nil) then
        local pressPoint = {x = rect.centerX, y = rect.centerY}
        modAdrUi.swipeByPoint(pressPoint, pressPoint, modAdrUi.__DEF_LONG_PRESS_STEPS)
        isLongPressed = true
    end
    
    return isLongPressed
end

-- ========================= 创建UI控件选择器(Sel: selector) ==============================

-- 通过 UI 控件的 ID 创建选择器
function modAdrUi.createUiSelByResId(resIdStr)
    return UiSelectorApi:resourceId(resIdStr)
end

-- 通过 UI 控件的 ID 和 instance 创建选择器
function modAdrUi.createUiSelByResIdAndInstance(resIdStr,instance)
    return modAdrUi.createUiSelByResId(resIdStr):instance(instance)
end

-- 通过 UI 控件的文本全内容创建选择器
function modAdrUi.createUiSelByText(txtStr)
    return UiSelectorApi:text(txtStr)
end

-- 通过 UI 控制的文本起始内容创建选择器
function modAdrUi.createUiSelByTextContains(txtStr)
    return UiSelectorApi:textContains(txtStr)
end

-- 通过 UI 控制的文本起始内容创建选择器
function modAdrUi.createUiSelByTextStartWith(txtStr)
    return UiSelectorApi:textStartsWith(txtStr)
end

-- 通过 UI 控制的描述信息创建选择器
function modAdrUi.createUiSelByDes(txtStr)
    return UiSelectorApi:description(txtStr)
end

-- 通过 UI 控制的类名创建选择器
function modAdrUi.createUiSelByClsNm(clsNmStr)
    return UiSelectorApi:className(clsNmStr)
end

-- 通过 UI 控件的类名和 instance 创建选择器
function modAdrUi.createUiSelByClsNmAndInstance(clsNmStr,instance)
    return modAdrUi.createUiSelByClsNm(clsNmStr):instance(instance)
end

-- 为上层提供基于字串指定模式来创建选择器
function modAdrUi.createUiSel(uiSrchMth, uiSrchStr)
    local selObj = nil

    if((not modUtil.isTextEmpty(uiSrchMth)) and (not modUtil.isTextEmpty(uiSrchStr))) then
        if(uiSrchMth == GCfg.SRCH_UI_MTH.RESID) then
            selObj = modAdrUi.createUiSelByResId(uiSrchStr)
        elseif(uiSrchMth == GCfg.SRCH_UI_MTH.TXT) then
            selObj =  modAdrUi.createUiSelByText(uiSrchStr)
        elseif(uiSrchMth == GCfg.SRCH_UI_MTH.TXTSTART) then
            selObj = modAdrUi.createUiSelByTextStartWith(uiSrchStr)
        elseif(uiSrchMth == GCfg.SRCH_UI_MTH.DES) then
            selObj = modAdrUi.createUiSelByDes(uiSrchStr)
        elseif(uiSrchMth == GCfg.SRCH_UI_MTH.CLSNM) then
            selObj = modAdrUi.createUiSelByClsNm(uiSrchStr)
        end
     end

     return selObj
end
-- ========================= 快速获取基本 UI 对象 ==============================
--判断指定的 View 对象是否存在
function modAdrUi.isUiObjExists(vwObj)
    local rlt = false
    if (vwObj ~= nil and vwObj:exists()) then
        rlt = true
    end
    return rlt
end

-- 根据选择器对象，不做任何等待情况下迅速查找 UI View 对象
function modAdrUi.getUiObjNoWaitBySel(selObj)
    return AutomatorApi:findObject(selObj)
end

-- 根据类名，不做任何等待情况下迅速查找 UI View 对象
function modAdrUi.getUiObjNoWaitByClsNm(clsNm)
    return modAdrUi.getUiObjNoWaitBySel(modAdrUi.createUiSelByClsNm(clsNm))
end

-- 根据 UI 控件ID，不做任何等待情况下迅速查找 UI View 对象
function modAdrUi.getUiObjNoWaitByResId(resIdStr)
    return modAdrUi.getUiObjNoWaitBySel(modAdrUi.createUiSelByResId(resIdStr))
end

-- 根据 UI 控件文本全内容，不做任何等待情况下迅速查找 UI View 对象
function modAdrUi.getUiObjNoWaitByText(txtStr)
    return modAdrUi.getUiObjNoWaitBySel(modAdrUi.createUiSelByText(txtStr))
end

-- 基于父UI对象获取其下的子对象，根据子选择器对象，不做任何等待情况下迅速查找子 UI View 对象
function modAdrUi.getChildUiObjNoWaitBySel(parentUiObj, childSelObj)
    local chdObj = nil
    if(modAdrUi.isUiObjExists(parentUiObj) and childSelObj ~= nil) then
        chdObj = parentUiObj:getChild(childSelObj)
    end
    return chdObj
end

-- 基于父UI对象获取其下的子对象，根据子 UI 控件ID，不做任何等待情况下迅速查找子 UI View 对象
function modAdrUi.getChildUiObjNoWaitByResId(parentUiObj, childResIdStr)
    return modAdrUi.getChildUiObjNoWaitBySel(parentUiObj, modAdrUi.createUiSelByResId(childResIdStr))
end

function modAdrUi.getChildUiObjNoWaitByText(parentUiObj, childTxtStr)
    return modAdrUi.getChildUiObjNoWaitBySel(parentUiObj, modAdrUi.createUiSelByText(childTxtStr))
end

function modAdrUi.getChildUiObjNoWaitByClsNm(parentUiObj, chilClsNm)
    return modAdrUi.getChildUiObjNoWaitBySel(parentUiObj, modAdrUi.createUiSelByClsNm(chilClsNm))
end

-- ========================= 获取 UI 对象相关信息 ==============================
-- 获取 UI 对象区域信息，以及中心点信息
function modAdrUi.getUiObjRect(vwObj)
    local rltRect = nil

    if(modAdrUi.isUiObjExists(vwObj)) then
        local bdObj = vwObj:getBounds()

        if(bdObj ~= nil) then
            rltRect = {}
            rltRect[RECT.left] = bdObj.left
            rltRect[RECT.top] = bdObj.top

            rltRect[RECT.right] = bdObj.right
            rltRect[RECT.bottom] = bdObj.bottom

            rltRect[RECT.centerX] = bdObj:centerX()
            rltRect[RECT.centerY] = bdObj:centerY()
        end
    end

    return rltRect
end

function modAdrUi.getUiObjCenterY(vwObj)
    local rltCenterY = 0

    if(modAdrUi.isUiObjExists(vwObj)) then
        local bdObj = vwObj:getBounds()
        if (bdObj ~= nil) then
            rltCenterY = bdObj:centerY()
        end
    end

    return rltCenterY
end

-- 获取 UI 对象的高度，不用 getUiObjRect 是考虑到这个时间更快
function modAdrUi.getUiObjHeight(vwObj)
    local rltHeight = 0

    if(modAdrUi.isUiObjExists(vwObj)) then
        local bdObj = vwObj:getBounds()
        if (bdObj ~= nil) then
            rltHeight = bdObj:height()
        end
    end

    return rltHeight
end


-- 获取 UI 对象的宽度
function modAdrUi.getUiObjWidth(vwObj)
    local rltWidth = 0

    if(modAdrUi.isUiObjExists(vwObj)) then
        local bdObj = vwObj:getBounds()
        if (bdObj ~= nil) then
            rltWidth = bdObj:width()
        end
    end

    return rltWidth
end

-- 获取 UI 对象的右边位置
function modAdrUi.getUiObjRight(vwObj)
    local rltRight = 0

    if(modAdrUi.isUiObjExists(vwObj)) then
        local bdObj = vwObj:getBounds()
        if (bdObj ~= nil) then
            rltRight = bdObj.right
        end
    end

    return rltRight
end

-- 获取 UI 对象的底部位置
function modAdrUi.getUiObjRight(vwObj)
    local rltRight = 0

    if(modAdrUi.isUiObjExists(vwObj)) then
        local bdObj = vwObj:getBounds()
        if (bdObj ~= nil) then
            rltRight = bdObj.right
        end
    end

    return rltRight
end

function modAdrUi.getUiObjBottom(vwObj)
    local rltBottom = 0

    if(modAdrUi.isUiObjExists(vwObj)) then
        local bdObj = vwObj:getBounds()
        if (bdObj ~= nil) then
            rltBottom = bdObj.bottom
        end
    end

    return rltBottom
end

-- 获取 Ui 集合中子控件的高度, 无法获取或本身高度为零时返回 0
function modAdrUi.getUiCollChildHeight(collObj, childSel, idx)
    return modAdrUi.getUiObjHeight(modAdrUi.getUiCollChildByInstance(collObj, childSel, idx))
end

-- 获取 Ui 集合中子控件的中心点y轴, 无法获取或本身高度为零时返回 0
function modAdrUi.getUiCollChildCenterY(collResIdStr, childResIdStr, idx)
    local collObj = modAdrUi.getUiCollByResId(collResIdStr)
    local childSel = modAdrUi.createUiSelByResId(childResIdStr)
    return modAdrUi.getUiObjCenterY(modAdrUi.getUiCollChildByInstance(collObj,childSel,idx))
end

-- ========================= 点击 UI 控制对象 ==============================
-- 根据要求点击控件对象
local function __clickUiObjNoWait(vwObj, isLongClick)
    local isClicked = false
    
    if (modAdrUi.isUiObjExists(vwObj)) then
        isClicked = true

        if (isLongClick) then
            isClicked = modAdrUi.longPress(vwObj)
        else
            vwObj:click()
        end
    end

    return isClicked
end

-- 基于 UI 控件对象普通点击
function modAdrUi.clickUiObjNoWait(vwObj)
    return __clickUiObjNoWait(vwObj, false)
end

-- 基于 UI 控件对象长按点击
function modAdrUi.longClickUiObjNoWait(vwObj)
    return __clickUiObjNoWait(vwObj, true)
end

-- 根据 UI 控件选择器，模拟点击
function modAdrUi.clickViewBySel(selector)
    local vwObj = modAdrUi.getUiObjNoWaitBySel(selector)
    return modAdrUi.clickUiObjNoWait(vwObj)
end

-- 根据 UI 控件类名，模拟点击
function modAdrUi.clickViewByClsNm(clsNm)
    local vwObj = modAdrUi.getUiObjNoWaitByClsNm(clsNm)
    return modAdrUi.clickUiObjNoWait(vwObj)
end

-- 根据资源 ID 字串，模拟点击
function modAdrUi.clickViewByResId(resIdStr)
    local vwObj = modAdrUi.getUiObjNoWaitByResId(resIdStr)
    return modAdrUi.clickUiObjNoWait(vwObj)
end

-- 根据资源 text 字串，模拟点击
function modAdrUi.clickViewByText(txtStr)
    local vwObj = modAdrUi.getUiObjNoWaitByText(txtStr)
    return modAdrUi.clickUiObjNoWait(vwObj)
end

--  根据资源 text 开始字串，模拟点击
function modAdrUi.clickViewByTextStartWith(txtStartWithStr)
    local vwObj = modAdrUi.getUiObjNoWaitBySel(modAdrUi.createUiSelByTextStartWith(txtStartWithStr))
    return modAdrUi.clickUiObjNoWait(vwObj)
end

-- ========================= 快速获取 UI 对象的Text、Des =========================
-- 获取对象的Text
function modAdrUi.getTextByUiObj(vwObj, defaultText)
    local rltVwText = defaultText

    if(modAdrUi.isUiObjExists(vwObj)) then
        rltVwText = vwObj:getText()
    end
   
    return rltVwText
end

-- 根据 UI 控件选择器，获取对象的text
function modAdrUi.getTextBySel(selector, defaultText)
    return modAdrUi.getTextByUiObj(modAdrUi.getUiObjNoWaitBySel(selector), defaultText) 

end

-- 根据 UI 控件ID，获取对象的text
function modAdrUi.getTextByResId(resStr, defaultText)
    return modAdrUi.getTextByUiObj(modAdrUi.getUiObjNoWaitByResId(resStr), defaultText) 
end

-- 根据 UI 控件ID，获取对象的text
function modAdrUi.getTextByClsNm(clsNm, defaultText)
    return modAdrUi.getTextByUiObj(modAdrUi.getUiObjNoWaitByClsNm(clsNm), defaultText) 
end

-- 获取对象的描述信息Des
function modAdrUi.getDesByUiObj(vwObj, defaultDes)
    local rltVwDes = defaultDes;

    if(modAdrUi.isUiObjExists(vwObj)) then
        rltVwDes = vwObj:getContentDescription();
    end
   
    return rltVwDes;
end

-- 根据 UI 控件选择器，获取对象的描述信息Des
function modAdrUi.getDesBySel(selector, defaultDes)
    return modAdrUi.getDesByUiObj(modAdrUi.getUiObjNoWaitBySel(selector), defaultDes)
end

-- 根据 UI 控件ID，获取对象的text
function modAdrUi.getDesByResId(resStr, defaultDes)
    return modAdrUi.getDesByUiObj(modAdrUi.getUiObjNoWaitByResId(resStr), defaultDes)
end

-- ========================= 快速获取 UI 控件集合 =========================
-- 根据 UI 控件 选择器 selector 获取 Ui 控件集合
function modAdrUi.getUiCollBySel(selector)
    return UiCollectionApi:getUiCollection(selector)
end

-- 根据资源 ID 获取 Ui 控件集合
function modAdrUi.getUiCollByResId(resIdStr)
    return modAdrUi.getUiCollBySel(modAdrUi.createUiSelByResId(resIdStr))
end

-- 根据 className 获取 Ui 控件集合
function modAdrUi.getUiCollByClsNm(clsNmStr)
    return modAdrUi.getUiCollBySel(modAdrUi.createUiSelByClsNm(clsNmStr))
end

-- 根据子资源 selector 对象获取 Ui 集合中子 Ui 个数
function modAdrUi.getUiCollChildCountBySel(collObj, childSel)
    local rltCount = 0

    if(collObj ~= nil and childSel ~= nil) then
        rltCount = collObj:getChildCount(childSel)
    end

    if (rltCount == nil) then
        rltCount = 0
    end

    return rltCount
end

-- 根据子资源 ID 条件值获取 Ui 集合中子 Ui 个数
function modAdrUi.getUiCollChildCountByResId(collObj, childResIdStr)
    return modAdrUi.getUiCollChildCountBySel(collObj, modAdrUi.createUiSelByResId(childResIdStr))
end

-- 根据集合类名 和 子资源 ID 条件值获取 Ui 集合中子 Ui 个数
function modAdrUi.getUiCollChildCountByClsNmAResId(collclsNmStr, childResIdStr)
    local collObj = modAdrUi.getUiCollByClsNm(collclsNmStr)
    return modAdrUi.getUiCollChildCountByResId(collObj, childResIdStr)
end

-- 获取 Ui 集合中指定的索引位置的子对象
function modAdrUi.getUiCollChildByInstance(collObj, childSel, idx)
    local rltChildObj = nil

    if(collObj ~= nil and childSel ~= nil and 0 <= idx) then
        rltChildObj = collObj:getChildByInstance(childSel, idx)
    end

    return rltChildObj
end

-- 集合类名 和 子资源 ID ,获取 Ui 集合中指定的索引位置的子对象
function modAdrUi.getUiCollChildByClsNmAResIdAInstance(collclsNmStr, childResIdStr, idx)
    local collObj = modAdrUi.getUiCollByClsNm(collclsNmStr)
    local childSel = modAdrUi.createUiSelByResId(childResIdStr)
    return modAdrUi.getUiCollChildByInstance(collObj, childSel, idx)
end

-- 获取 Ui 集合中指定资源 ID 及 序数的文本内容
function modAdrUi.getUiCollChildTextByInstance(collObj, childSel, idx, defaultTxt)
    local childObj = modAdrUi.getUiCollChildByInstance(collObj, childSel, idx)
    return modAdrUi.getTextByUiObj(childObj, defaultTxt)
end

-- 集合类名 和 子资源 ID ,获取 Ui 集合中指定资源 ID 及 序数的文本内容
function modAdrUi.getUiCollChildTextByClsNmAResIdAInstance(collclsNmStr, childResIdStr, idx, defaultTxt)
    local childObj = modAdrUi.getUiCollChildByClsNmAResIdAInstance(collclsNmStr, childResIdStr, idx)
    return modAdrUi.getTextByUiObj(childObj, defaultTxt)
end

-- ========================= 模块返回，必须有 ==============================
return modAdrUi