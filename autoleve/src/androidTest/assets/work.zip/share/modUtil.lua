
-------------------------------------------------- 模块：基本工具模块 -------------------------------------------------------
-- 说明：为所有其他模块提供基本开发API工具套件, 模块命名规则：mod + 具体模块名
-- require ("socket")
-- __funcSleep = function (mSecs) socket.select(nil, nil, mSecs) end,

local modUtil = {
    isDebug = true, 
    __funcSleep = function (mSecs)  return mSecs end,
    __funcCurMsec = function () return 0 end, __lastMSec = 0,

    __funcLogI = print, LOGI_TAG = "LuaDbg_i: ",
    __funcLogE = print, LOGE_TAG = "LuaDbg_e: ",

}

local javaFun = require("share.javaFun")

-- ========================= 初始化接口 ==============================
-- 模块初始化接口
function modUtil.init(sleepFunc, getCurMSecFunc, logIFunc, logEFunc)
    if(sleepFunc ~= nil) then
        modUtil.__funcSleep = sleepFunc
    end
    if(getCurMSecFunc ~= nil) then
        modUtil.__funcCurMsec = getCurMSecFunc
    end
    if(logIFunc ~= nil) then
        modUtil.__funcLogI = logIFunc
    end
    if(logEFunc ~= nil) then
        modUtil.__funcLogE = logEFunc
    end
end

-- ========================= 文件读写工具 ==============================

function modUtil.file_exists(path)
    local rlt = false
    if(not modUtil.isTextEmpty(path)) then
        local file = io.open(path, "rb")
        if file then 
            file:close() 
        end
        rlt = file ~= nil
    end
	return rlt
end

--读取文件中全部内容
function modUtil.read_files(pathName)
	local content = ""
	if(not modUtil.isTextEmpty(pathName) and modUtil.file_exists(pathName)) then 
		local file = io.open(pathName,'r')
		content = file:read("*all")
        if file then
            io.close(file)
        end
	end
	return content
end 

function modUtil.write_files(pathName,content)
	--[[local  file = assert(io.open(pathName,'w'))
	file:write(content)
    file:close()]]
    if(not modUtil.isTextEmpty(pathName) and not modUtil.isTextEmpty(content)) then
        local file = io.open(pathName, "w")
        io.output(file)
        io.write(content)
        if file then
            io.close(file)
        end
    end
end


-- ========================= 格式转换工具 ==============================
--各种类型转String，如table、number等转string(序列化)
function modUtil.serialize(obj)
    local str = ""
    if (obj == nil) then
        return str
    end
    local t = type(obj)
    if t == "number" then
        str = str .. obj
    elseif t == "boolean" then
        str = str .. tostring(obj)
    elseif t == "string" then
        str = str .. string.format("%q", obj)
    elseif t == "table" then
        str = str .. "{\n"
    for k, v in pairs(obj) do
        str = str .. "[" .. modUtil.serialize(k) .. "]=" .. modUtil.serialize(v) .. ",\n"
    end
    local metatable = getmetatable(obj)
        if metatable ~= nil and type(metatable.__index) == "table" then
        for k, v in pairs(metatable.__index) do
            str = str .. "[" .. modUtil.serialize(k) .. "]=" .. modUtil.serialize(v) .. ",\n"
        end
    end
        str = str .. "}"
    elseif t == "nil" then
        return nil
    else
        error("can not serialize a " .. t .. " type.")
    end
    return str
end
 
--string转各种类型：table、numble等(反序列化)
function modUtil.unserialize(src)
    local t = type(src)
    if t == "nil" or src == "" then
        return nil
    elseif t == "number" or t == "string" or t == "boolean" then
        src = tostring(src)
    else
        error("can not unserialize a " .. t .. " type.")
    end
    src = "return " .. src
    local func = loadstring(src)
    if func == nil then
        return nil
    end
    return func()
end
 
--将单层table转换成json格式
function modUtil.tableToJson(tb)
    local jsonObject = javaFun.newJSONObject()
    if ("table" == type(tb) and not modUtil.isTableEmpty(tb)) then
        for k,v in pairs(tb) do
            jsonObject:put(k,v)
        end
    end
    return jsonObject
end

-- ========================= 数学工具 ==============================
-- 获取一个数字的绝对值
function modUtil.abs(num)
    if(num < 0) then
        num = -num
    end
    return num
end

-- 求 utc 时间差绝对值
function modUtil.utcTimeDiff(curMSec, lastMSec)
    return modUtil.abs(curMSec - lastMSec)
end

-- ========================= 字串处理工具 ==============================
-- 判断字串是否为空，字串为空时返回真，否则返回假
function modUtil.isTextEmpty(txtStr)
    return txtStr == nil or txtStr == "" 
end

-- 判断字串是否以某个前缀开头
function modUtil.starts(srcStr, PrefixStr)
    return (not modUtil.isTextEmpty(srcStr)) and (string.sub(srcStr, 1, string.len(PrefixStr)) == PrefixStr)
end
 
-- 判断字串是否以某个后缀结尾
function modUtil.ends(srcStr, suffixStr)
    return (not modUtil.isTextEmpty(srcStr)) and (suffixStr == '' or string.sub(srcStr, -string.len(suffixStr)) == suffixStr)
end

-- 原始字串包含特定前缀的情况下，切取没有前缀后的子串内容 
function modUtil.sliceWithoutPrefixStr(srcStr, prefixStr)
    if(modUtil.starts(srcStr, prefixStr) and string.len(prefixStr) < string.len(srcStr)) then
        local rltDt = string.sub(srcStr, #prefixStr + 1)
        return {rltDt, prefixStr}
    end

    return nil
end

-- 按指定字串为拆分符号拆分字串
function modUtil.split(str, reps)
    local resultStrList = {}

    string.gsub(str,'[^'..reps..']+', function ( w )
        table.insert(resultStrList, w)
    end)
    return resultStrList
end

-- 移除字串两端空白符号
function modUtil.trim(str)
    return (string.gsub(str, "^%s*(.-)%s*$", "%1"))
end

-- 移除字串中所有空白符号
function modUtil.trimAll(str)
    return (string.gsub(str, "%s*", ""))
end

-- 字串或table相等比较
function modUtil.equals(srcObj, cmpObj)
    local rlt = false

    if(srcObj ~= nil and cmpObj ~= nil) then   
        if(type(srcObj) == "string" and type(cmpObj) == "string" and srcObj == cmpObj) then
            rlt = true
        elseif(type(srcObj) == "table" and type(cmpObj) == "table") then
            rlt = modUtil.cmpObj(srcObj, cmpObj)
        end
    elseif (srcObj == nil and cmpObj == nil) then  -- 两个空判断为不相等
        rlt = false
    end

    return rlt
end

-- 两个对象值比较，相等返回真，不相等返回假
function modUtil.cmpObj(obj1, obj2)
    local rlt = true
    
    if(obj1 == nil or obj2 == nil) then
        return false
    end

    for key, value in pairs(obj1) do
        if(obj2[key] == nil or obj2[key] ~= value) then
            rlt = false
            break
        end
    end
    
    return rlt
end

-- 字串包含判断
function modUtil.contains(sourceStr, compareStr)
    return javaFun.contains(sourceStr, compareStr)
end
-- ========================= 表格处理工具 ==============================
-- 获取一个table的所有key,再封装为一个table返回
function modUtil.getTableKeys(tb)
    local rltKeys = {}

    if(tb ~= nil) then
        for key, value in pairs(tb) do
            table.insert(rltKeys, key)
        end
    end

    return rltKeys
end

-- 把一个表的数据按指定位置偏移添加到另外一个表中，包括开始offsetPos位置，结束位置offsetPos的两个元素
function modUtil.addToTable(dstTb, srcTb, offsetPos, endPos)
    if(dstTb ~= nil and srcTb ~= nil and 0 < offsetPos and offsetPos <= #srcTb ) then
        if (endPos == -1) then
            endPos = #srcTb
        end

        if (endPos < offsetPos) then
            return dstTb
        end

        for i = offsetPos, endPos do
            table.insert(dstTb, srcTb[i])
        end
    end
    return dstTb
end

-- 判断表是否为空
function modUtil.isTableEmpty(tb)
    return tb == nil or _G.next( tb ) == nil
end


-- ========================= 与外围注入实际接口有关的工具 ==============================
-- 普通日志打印工具
function modUtil.logI(logStr)
    if (modUtil.isDebug) then
        modUtil.__funcLogI(modUtil.LOGI_TAG .. logStr)
    end
end

-- 错误日志打印工具
function modUtil.logE(logStr)
    if (modUtil.isDebug) then
        modUtil.__funcLogE(modUtil.LOGE_TAG .. logStr)
    end
end

-- 休眠毫秒时间
function modUtil.sleep(mSec)
    if (type(mSec) == "number" and mSec > 0) then
        modUtil.__funcSleep(mSec);
    else
        modUtil.LogI("睡眠时间不符合格式...")
    end
end

-- 获取当前毫秒时间搓
function modUtil.getCurMSec()
    return modUtil.__funcCurMsec()
end

-- 模块日志打印开始
function modUtil.modLogTestBegin(modTag, info, isModBegin)
    if(isModBegin ~=nil and isModBegin) then
        modUtil.logE(modTag .. " >>>>>>>>>>------------[ " .. modTag .. " ] begin ------------>>>>>>>>>>")
    else
        modUtil.logE(modTag .. " ------------>> begin Func: [" .. info .. "] <<------------ ")
    end
end

-- 模块日志打印结束
function modUtil.modLogTestEnd(modTag, info, isModEnd)
    if(isModEnd ~= nil and isModEnd) then
        modUtil.logE(" <<<<<<<<<<------------[ " .. modTag .. " ] finish ------------<<<<<<<<<<")
    else
        modUtil.logE(modTag .. " ------------<< end Func: [" .. info .. "] >>------------ ")
    end
end

-- 打印日志，并自动计算上条日志和这条日志间的耗时时间，单位：毫秒
function modUtil.logWithUseTime(logStr, isResetCurMsec)
    local useMSec = modUtil.getCurMSec() - modUtil.__lastMSec
    
    if(isResetCurMsec ~= nil and isResetCurMsec) then
        modUtil.logE("[UseMS: BeginCalUseTm] " .. logStr)
    else
        modUtil.logE("[UseMS: " .. useMSec .. "] " .. logStr)
    end

    modUtil.__lastMSec = modUtil.getCurMSec()
end

-- ========================= 杂项功能 ==============================
-- 不做任何事情的空函数，或留到以后做，desc：描述信息
function modUtil.doNone(desc)
    if(desc ~= nil) then
        modUtil.logI("[Func: doNone]: " .. desc)
    end
end

-- ========================= 模块接口测试 ==============================
modUtil.testMode = function()
end



-- ========================= 模块返回，必须有 ==============================
return modUtil

