require 'import'
import 'com.al.autoleve.core.automator.api.AutomatorApi'
import 'com.al.autoleve.core.automator.util.AutoUtil'

local javaFun = {}

---------------------------- 界面接口 ---------------------------
function javaFun.checkApkExist(pkName)
    return AutoUtil:checkApkExist(pkName)
end

function javaFun.startApp(pkName)
    AutomatorApi:startApp(pkName)
end

function javaFun.stopApp(pkName)
    AutomatorApi:stopApp(pkName)
end

function javaFun.backToDeskTop()
    AutomatorApi:backToDeskTop()
end

function javaFun.pressBack()
    AutomatorApi:pressBack()
end

function javaFun.getDisplayWidth()
    return AutomatorApi:getDisplayWidth()
end

function javaFun.swipe(startX, startY, endX, endY, steps)
    AutomatorApi:swipe(startX, startY, endX, endY, steps)
end

function javaFun.click(x,y)
    AutomatorApi:click(x,y)
end

function javaFun.longClickUiObect(vmObj)
    AutomatorApi:longClickUiObect(vmObj)
end

function javaFun.registerWatcher(watcherName, checkSel, optSel)
    AutomatorApi:registerWatcher(watcherName, checkSel, optSel, nil)
end

function javaFun.registerWatcher(watcherName, checkSel, optSel, nextOptSel)
    AutomatorApi:registerWatcher(watcherName, checkSel, optSel, nextOptSel)
end

---------------------------- 工具接口 ---------------------------

function javaFun.setTaskActionResult(rlt)
    -- body
    AutoUtil:setTaskActionResult(rlt)
end
function javaFun.setTaskActionResultAndDesc(rlt,desc)
    -- body
    AutoUtil:setTaskActionResult(rlt,desc)
end
-- 用于lua层获取钉钉账号
function javaFun.getDingDingAccount()
    -- body
    return AutoUtil:getDingDingAccount()
end
-- 用于lua层获取钉钉密码
function javaFun.getDingDingPwd()
    -- body
    return AutoUtil:getDingDingPwd()
end
-- 用于java层获取打卡类型
function javaFun.getPushType()
    -- body
    return AutoUtil:getPushType()
end
-- 为一些组件设置文本
function javaFun.inputEditText(etobj,rlt)
    -- body
    AutoUtil:inputEditText(etobj,rlt)
end


return javaFun