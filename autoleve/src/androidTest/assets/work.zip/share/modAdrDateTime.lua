--------------------------------------------------模块：Android 日期与时间工具模块  -------------------------------------------------------
-- 说明：为所有其他模块提供日期与时间操作的工具
----------------- 导入 Java 层 API 接口 -----------------
require 'import'
import 'com.al.autoleve.core.automator.util.TimeUtil'

----------------- 导入 Lua 层 API 接口 -----------------
local modUtil = require("share.modUtil")


local modAdrDateTime = {
    DATA_TIME_FORMATOR = "yyyy-MM-dd HH:mm:ss",
    CN_TODAY = "今天",
    CN_YESTERDAY = "昨天"
}


-- ========================== 常用日期功能函数 =============================
-- 根据传入的时间，获取正常的时间样式
function getSuitDateTime(dtStr)
    local rlt = nil
    local startPos, endPos, yearStr, monthStr, dayStr = string.find(dtStr, "^(%d+)-(%d+)-(%d+)")

    if(startPos ~= nil and endPos ~= nil and yearStr ~= nil and monthStr ~= nil and dayStr ~= nil) then
        local isValid = false

        local year = tonumber(yearStr)
        local month = tonumber(monthStr)
        local day = tonumber(dayStr)
        local hourStr = ""

        if (10 <= year and year <= 99) then
            year = 2000 + year
            isValid = true
        elseif (1900 <= year and year <= 9999) then
            isValid = true
        else
            isValid = false
        end

        if(isValid) then
            if (1 <= month and month <= 9) then
                month = "0" .. month
            elseif (10 <= month and month <= 12) then
                isValid = true
            else
                isValid = false
            end
        end

        if(isValid) then
            local isStartWithZero = modUtil.starts(dayStr, "0")
            local dayStrLen = string.len(dayStr)

            if (isStartWithZero and 3 <= dayStrLen) then
                day = string.sub(dayStr, 1, 2)
                hourStr = string.sub(dayStr, 3, dayStrLen)
            elseif(1 <= day and day <= 9) then
                day = "0" .. day
            elseif (10 <= day and day <= 31) then
                isValid = true
            else              
                day = string.sub(dayStr, 1, 2)
                hourStr = string.sub(dayStr, 3, dayStrLen)
                local hour = tonumber(hourStr)
                if(0 <= hour and hour <= 9) then
                    hourStr = "0" .. hour
                elseif(10 <= hour and hour<= 23) then
                    hourStr = "" .. hour
                else
                    isValid = false
                end    
            end
        end

        if (isValid) then
            rlt = year .. "-" .. month .. "-" .. day .. " " .. hourStr .. modUtil.trim(string.sub(dtStr, endPos + 1))
        end
    end

    return rlt
end


-- 获取现在年份，比如 2018 代表 2018年
function modAdrDateTime.getCurYear()
    return TimeUtil:getCurYear()
end

-- 获取今天对应的月日，月日各占两位,如：06-01：表示6月1日
function modAdrDateTime.getTdayMonthDay()
    return TimeUtil:getCurMonthDay()
end

-- 获取昨天对应的月日，月日各占两位,如：06-01：表示6月1日，如果今天为6.1日，算出的昨天为05.31日
function modAdrDateTime.getYdayMonthDay()
    return TimeUtil:getYesterdayMonthDay()
end

-- 获取昨天对应的年月日，月日各占两位,如：2018-06-01
function modAdrDateTime.getTodaysDate()
    return TimeUtil:getTodaysDate()
end

-- 返回两个日期间相差的天数，正整数
function modAdrDateTime.getDaysBetweenDates(date1,date2)
    return TimeUtil:getDaysBetweenDates(date1,date2)
end

-- 获取距离今天的任何一天，正数往未来推，负数往已过完的天推
function modAdrDateTime.getMonthDayOfDistanceTday(offDay)
    return TimeUtil:getMonthDayOfDistanceToday(offDay)
end

-- 转换时间字串到Utc毫秒时间，传入时间格式样列："2018-05-26 01:23:46"
function modAdrDateTime.convDtmStrToUtcMSec(dateTimeStr)
    local rlt = 0
    if (dateTimeStr ~= nil and dateTimeStr ~= "") then
        rlt = TimeUtil:stringToLong(dateTimeStr, modAdrDateTime.DATA_TIME_FORMATOR)
    end
    return rlt
end

-- 转换Utc毫秒时间到时间字串（如：yyyy-MM-dd HH:mm:ss），传入时间格式Utc时间，long型
function modAdrDateTime.convUtcMSecToDtmStr(utcLongTime)
    local rlt = 0
    if (utcLongTime ~= nil and utcLongTime ~= "") then
        rlt = TimeUtil:longToString(utcLongTime, modAdrDateTime.DATA_TIME_FORMATOR)
    end
    return rlt
end

-- 翻译中文的 "今天", "昨天" 字串到真实的月日，月日各占两位, 如：06-01：表示6月1日
function modAdrDateTime.convCNTdayOrYdayToMonthDay(cNTodayOrYesterday)
    local rltMd =  cNTodayOrYesterday

    if(cNTodayOrYesterday ~= nil and cNTodayOrYesterday ~= "") then
        if(modUtil.equals(cNTodayOrYesterday, modAdrDateTime.CN_TODAY)) then
            rltMd = modAdrDateTime.getTdayMonthDay()
        elseif (modUtil.equals(cNTodayOrYesterday, modAdrDateTime.CN_YESTERDAY)) then
            rltMd = modAdrDateTime.getYdayMonthDay()
        end
    end

    return rltMd
end

-- 转换UI层面的时间信息到 UTC 毫秒值
function modAdrDateTime.convUiMonthDayHourMinuteStrToUtcMSec(mdhmStr)
    local rltMSec  = 0

    if(not modUtil.isTextEmpty(mdhmStr)) then
        mdhmStr = modUtil.trim(mdhmStr)  -- 移除两端空格，防止解析错乱

        local hmInfo = modUtil.sliceWithoutPrefixStr(mdhmStr, modAdrDateTime.CN_TODAY) or modUtil.sliceWithoutPrefixStr(mdhmStr, modAdrDateTime.CN_YESTERDAY)
        local realMdhmStr = mdhmStr
        
        if(hmInfo ~= nil and 2 == #hmInfo and not modUtil.isTextEmpty(hmInfo[1])) then
            realMdhmStr = modAdrDateTime.convCNTdayOrYdayToMonthDay(hmInfo[2]) .. hmInfo[1]
        end

        local stYDt =  getSuitDateTime(realMdhmStr)

        if(stYDt ~= nil) then
            rltMSec = modAdrDateTime.convDtmStrToUtcMSec(stYDt)
        else
            realMdhmStr = modAdrDateTime.getCurYear() .. "-" .. realMdhmStr
            realMdhmStr = modUtil.trimAll(realMdhmStr)

            if(15 <= string.len(realMdhmStr)) then  -- 当前日期格式样列："2018-01-2503:09:08"
                realMdhmStr = string.sub(realMdhmStr, 1, 10) .. " " .. string.sub(realMdhmStr, 11) 
                rltMSec = modAdrDateTime.convDtmStrToUtcMSec(realMdhmStr)
            end 
        end
    end

    return rltMSec
end

-- 进行字串表示的两个时间差相减，性能高
function modAdrDateTime.calcDtmDiffAbs(curDtmStr, lastCurDtmStr)
    return modUtil.abs(modAdrDateTime.convDtmStrToUtcMSec(curDtmStr),  modAdrDateTime.convDtmStrToUtcMSec(lastCurDtmStr))
end

-- 进行UI层字串表示的两个时间差相减，性能差点，但自适应性好，支持灵活支持各种形式的子串，具体查看 test_modAdrDateTime 中的测试样列传入值
function modAdrDateTime.calcUiDtmStrDiffAbs(curDtmStr, lastCurDtmStr)
    return modUtil.abs(modAdrDateTime.convUiMonthDayHourMinuteStrToUtcMSec(curDtmStr),  modAdrDateTime.convUiMonthDayHourMinuteStrToUtcMSec(lastCurDtmStr))
end



-- ========================= 模块返回，必须有 ==============================
return modAdrDateTime